# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://dwikler.github.io/my-use-case-ig/ImplementationGuide/my-use-case-ig | *Version*:0.1.0 |
| Draft as of 2025-11-09 | *Computable Name*:MyUseCaseIG |

# MyUseCaseIG

Welcome to the MyUseCase Implementation Guide

## Introduction

Contains constraints and extensions to support MyUseCase.

## Overview

This IG defines one profile for the Patient resource.

